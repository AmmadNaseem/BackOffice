<footer>
        <!-- Copyright -->
        <div class="footer fixed-bottom" style="background-color: rgba(0, 0, 0, 0.2); text-align: center">
            © 2019 Copyright:
            <a class="text-dark" href>- AzoresSkills</a>
        </div>
        <!-- Copyright -->
    </footer>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>